
<html>
        <head>
                <meta name="google-signin-client_id" content="189891022462-er7gi6pphlsu2pt3r4quaif8578b3e2j.apps.googleusercontent.com">
                <script src="https://apis.google.com/js/platform.js" async defer></script>
        </head>
        <body>
          
                <div class="g-signin2" data-onsuccess="gmailLogIn"></div>
                
             <script>
                function gmailLogIn(userInfo){
                     console.log(gmailLogIn);
                }
               </script>
                
        <!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        </body>
</html>

